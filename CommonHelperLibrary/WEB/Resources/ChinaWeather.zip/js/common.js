var gDefaults= {
    province: "99",
    city: "0",
    district: "0"
};
var yjtype= Array ('01','02','03','04','05','06','07','08','09','10','11','12','13','14','91','92','93','94');
var yjyc = Array ('01','02','03','04','05');
// 读取设置
//
function readSetting(key, defaultValue) {
    var value = System.Gadget.Settings.read(key);
    if (typeof (value) == "string" && arguments.length == 2) {
        value = value || defaultValue;
    }
    return value;
}

// 写入设置
//
function writeSetting(key, value) {
    System.Gadget.Settings.write(key, value);
}

// 定位用户地理位置
//
function locateUser(callback) {
    var callee = arguments.callee;
    
    if (!window.locateErrors) {
        window.locateErrors = 0;
    }

	loadSettings();

    if (gDefaults.province == "99") {
        var rs = "http://61.4.185.48:81/g/";
        $.ajax({
            url: rs,
            cache: false,
            success: function(data) {
                window.locateErrors = 0;
                if (data) {
                    var regex = /id=(\d+);/i;
                    var matchs = data.match(regex);

					gDefaults.province=matchs[1].substr(0,5) ;
					gDefaults.city=matchs[1].substr(5,2);
					gDefaults.district=matchs[1].substr(7,2);
					parseCityId();
                    System.Gadget.Settings.writeString("district",gDefaults.province+gDefaults.city+gDefaults.district); 
                }

                if (callback && $.isFunction(callback)) {
                    callback(genCityId());
                }
            },
            error: function(xhr,status,errMsg) {
                window.locateErrors++;
                if (window.locateErrors <= 5) {
                    setTimeout(function() {
                        callee(callback);
                    }, 100);
                }
                else {
                    window.locateErrors = 0;
                    drawMsg("网络或服务异常！");
                }
            }
        });
    } else {
        if (callback && $.isFunction(callback)) {
            callback(genCityId());
        }
    }
}

//
// 加载所有设置
//
function loadSettings() {
	//System.Gadget.Settings.writeString("district","11101010"); 
	//$("#picInfo").html("<div id='headInfo'>"+	System.Gadget.Settings.readString("district")+"543S</div>");
	gDefaults.province=System.Gadget.Settings.readString("district").substr(0,5) ||"99";
	gDefaults.city=System.Gadget.Settings.readString("district").substr(5,2);
	gDefaults.district=System.Gadget.Settings.readString("district").substr(7,2);
}
function parseCityId(){
	if(gDefaults.district=="00"){
		gDefaults.district = gDefaults.city;
		gDefaults.city = "00";
	}
}
//获取城市信息的时候，末尾为00的为直辖市，调换两者位置；如果是存储，和城市接口保持一致
function genCityId(){
	if(gDefaults.city!="00"){
		return gDefaults.province+gDefaults.city+gDefaults.district;
	}else{
		return gDefaults.province+gDefaults.district+gDefaults.city;
	}
}
//
// 保存所有设置
//
function saveSettings() {
    writeSetting("Defaults", JSON.stringify(gDefaults));
}

System.Gadget.settingsUI = "settings.html";
System.Gadget.Flyout.file = "forecast.html";
System.Gadget.onSettingsClosed = getInfo;
System.Gadget.onSettingsClosing = onSettingsClosing;
// 点击确定或取消时执行
//
function onSettingsClosing(event) {
    if (event.closeAction == event.Action.commit) {
		System.Gadget.Settings.writeString("district",$("#yourcity").text()); 
		System.Gadget.document.parentWindow.myRefresh();
        return false;
    }
    event.cancel = false;
}
//System.Gadget.Flyout.onHide = hideFlyout;

function showFlyout()
{
	if(!System.Gadget.Flyout.show){
		
		//$("#citynameid",System.Gadget.Flyout.document).empty();
		//oFlyoutDocument.getElementById("citynameid").innerText = "12345";
		/*if(oFlyoutDocument){
			$("#citynameid",oFlyoutDocument).empty();
			//oFlyoutDocument.getElementById("citynameid").innerText = "12345";
		}*/
		System.Gadget.Flyout.show= true;
		/*var oFlyoutDocument = System.Gadget.Flyout.document;
		oFlyoutDocument.getElementById("citynameid").innerText = "12345";
		$("#headInfo").append("<p>true"+oFlyoutDocument.getElementById("citynameid").innerText+"</p>");*/
	}
}
// --------------------------------------------------------------------
// 隐藏飞出
// --------------------------------------------------------------------
function hideFlyout()
{
	if(System.Gadget.Flyout.show){
		System.Gadget.Flyout.show= false;
	}
}
	function getInfo(cityid) {
	$.ajax( {
		type : "GET",
		url : "http://data.weather.com.cn/sk/" + cityid + ".html",
		cache : false,
		data : {},
		dataType : "json",
		success : function(result) {
			var cityName = result.weatherinfo.city;
			var temp = result.weatherinfo.temp;
			var WD = result.weatherinfo.WD;
			var WSE = result.weatherinfo.WSE;
			var time = result.weatherinfo.time;
			var SD=result.weatherinfo.SD;
			var WS=result.weatherinfo.WS;
			var date =new Date();
			var showDate=date.getFullYear()+"-"+(date.getMonth()+1)+"-"+date.getDate()+"  "+time+"发布";
			if(temp=="暂无实况")
			{
				$("#rightTitle").html("<p style='position:relative;top:-5px;'>当前实况：<span id='mainTmpzw'>"+temp+"</span></p>");
			}
			else
			{
				$("#rightTitle").html("<p style='position:relative;top:-5px;'>当前实况<span id='mainTmp'>"+ temp + "℃</span></p>");	
			}
			$("#divcityName").html("<a href='javascript:void(0);' id='refresh' onclick= 'myRefresh();'></a>"+cityName);
			$("#divmarqueee").empty();
			$("#alarmDiv").empty();
			getZS(cityid);
			getInfo2(cityid);
			getWarning(cityid);
		},
		error : function(e) {
			alert(e);
		}
	});
}

function getInfo2(cityid){
	$.ajax({
	type: "GET",
	url: "http://data.weather.com.cn/forecast/"+cityid+".html", 
	cache: false,
	data: {}, 
	dataType: "json",
	success: function(result){
	var temp1=result.weatherinfo.temp1;
	var weather1=result.weatherinfo.weather1;
	var wind1=result.weatherinfo.wind1;
	var pic=result.weatherinfo.img1<10?("0"+result.weatherinfo.img1):result.weatherinfo.img1;
	var showDate=result.weatherinfo.date_y+" "+result.weatherinfo.fchh+"时发布";
	$("#headInfo").html("<p><a href='http://www.weather.com.cn' target='_blank'><img src='../imgs/logo_weather.png' width='24px;' height='24px;' style='position:relative;top:5px;left:0px;'></a>&nbsp;&nbsp;"+showDate+"</p>");
	if(wind1.length>10 &&  weather1.length<11)
	{
	$("#rightContent").html("<p>"+weather1+"</p><marquee onmouseover='this.stop()' onmouseout='this.start()'  height='20px' width='113px' direction='left' scrollAmount=3 ><p>"+wind1+"</p></marquee><p>"+temp1+"</p>");	
	}
	else if(weather1.length>10 &&  wind1.length<11)
	{
		$("#rightContent").html("<marquee onmouseover='this.stop()' onmouseout='this.start()'  height='20px' width='113px' direction='left' scrollAmount=3 ><p>"+weather1+"</p></marquee><p>"+wind1+"</p><p>"+temp1+"</p>");	
	}
	else if(wind1.length>10 && weather1.length>10)
	{
			$("#rightContent").html("<marquee onmouseover='this.stop()' onmouseout='this.start()'  height='20px' width='113px' direction='left' scrollAmount=3 ><p>"+weather1+"</p></marquee><marquee onmouseover='this.stop()' onmouseout='this.start()'  height='20px' width='113px' direction='left' scrollAmount=3 ><p>"+wind1+"</p></marquee><p>"+temp1+"</p>");		
	}
	else
	{
	$("#rightContent").html("<p>"+weather1+"</p><p>"+wind1+"</p><p>"+temp1+"</p>");
	}
	var don="";
	if(result.weatherinfo.fchh<18){
		don="day/d";
	}else{
		don="night/n";
	}
	$("#innerLeft").css({"background-image" : "url(../imgs/100big/"+don + pic + ".png)"}); 
	},
	error: function(e){alert(e);}
	}
	);
}
//指数滚动代码
function AutoScroll(obj){
        $(obj).find("ul:first").animate({
                marginTop:"-25px"
        },500,function(){
                $(this).css({marginTop:"0px"}).find("li:first").appendTo(this);
        });
}
function getZS(cityid){
	$.ajax({
		type : "GET",
		url : "http://data.weather.com.cn/zsLenovo/" + cityid + ".html",
		cache : false,
		data : {},
		dataType : "json",
		success : function (result){
			var ag_name=result.zs[0].name;
			var ag_hint=result.zs[0].hint;
			var ac_name=result.zs[1].name;
			var ac_hint=result.zs[1].hint;
			var cl_name=result.zs[2].name;
			var cl_hint =result.zs[2].hint;
			var co_name =result.zs[3].name;
			var co_hint =result.zs[3].hint;
			var ct_name =result.zs[4].name;
			var ct_hint =result.zs[4].hint;
			$("#divmarqueee").html("<ul><li>"
			+ag_name
			+"："+
			ag_hint+"</li><li>"
			+ac_name
			+"："+
			ac_hint+"</li><li>"
			+cl_name
			+"："+
			cl_hint+"</li><li>"
			+co_name
			+"："+
			co_hint+"</li><li>"
			+ct_name
			+"："+
			ct_hint+"</li></ul>");
			//$("#divmarqueee").Scroll({line:1,speed:500,timer:4000});
			try{clearInterval($gd)}catch(e){}
			$gd=setInterval('AutoScroll("#divmarqueee")',5000);
		},
	error : function(e) {alert(e);}
	});
}
//增加的
function getWarning(cityid){
	$yjlb=['台风','暴雨','暴雪','寒潮','大风','沙尘暴','高温','干旱','雷电','冰雹','霜冻','大雾','霾','道路结冰'];
	$gdlb=['寒冷','灰霾','雷雨大风','森林火险','降温','道路冰雪'];
	$yjyc=['蓝色','黄色','橙色','红色'];
	$gdyc=['白色'];
	$.ajax({
		type: "GET",
		url: "http://product.weather.com.cn/alarm/stationalarm.php?areaid="+cityid+"&count=1&order=citylevel", 
		cache: false,
		data: {}, 
		dataType: "script",
		success: function(){	
			$.each(alarminfo.data,function(i,k){
				$filename=k[1];
				$pos=$filename.lastIndexOf('-');
				$lb=$filename.substr($pos+1,2);
				$jb=$filename.substr($pos+3,2);
				$img =$lb+$jb;
				$textlb=$yjlb[parseInt($lb,10) -1 ];
				$textyc=$yjyc[parseInt($jb,10) -1 ];
				if ($lb >90 || $jb > 90)$img ='0000';
				if ($lb >90) $textlb=$gdlb[parseInt($lb,10) - 91 ];
				if ($jb  >90) $textyc=$gdyc[parseInt($jb,10) - 91 ];
				var img="../imgs/warn/"+$img+".gif";
				$yjtext=k[0]+"发布"+$textlb+$textyc+"预警!";
				$yjtextstr=$yjtext.substr(0,14)+"...";
				var content="<marquee onmouseover='this.stop()' onmouseout='this.start()'  height='30px' width='200px' direction='left' scrollAmount=3 ><img id='alarm' src="
			+img+"></img><a href='http://www.weather.com.cn/alarm/newalarmcontent.shtml?file="+$filename+"'>"+$yjtextstr+"</a></marquee>";
				$("#alarmDiv").html(content);
	
		  });
		},
		error: function(e){alert(e);}
		});
} 

function myRefresh(){
	loadSettings();
	getInfo(genCityId());
}

setInterval('myRefresh()',10*60*1000);