/*var gDefaults= {
    province: "10107",
    city: "12",
    district: "04"
};*/

function getProvinceList(province,city,district)
{
	$.ajax( {
		type : "GET",
		url : "http://data.weather.com.cn/city3jdata/china.html",
		cache : false,
		data : {},
		dataType : "json",
		success : function (result){
			var str = '<select>';
			var objson = eval(result);
			for(var o in objson) {
				 str += '<option value="' + o + '">' + objson[o] + '</option>';
			}
			//$("ul li:first").append("<select id='Province' name='Select1' style='display:none'></select>");
			$("#Province").append($(">option", str + '</select>'));
			$("#Province").val(province);
			getCityList($("#Province").val(),city,district);
		},
		error : function(e) {
			alert(e);
		}
	});
}
function getCityList(id,city,district)
{
	$.ajax( {
		type : "GET",
		url : "http://data.weather.com.cn/city3jdata/provshi/"+ id +".html",
		cache : false,
		data : {},
		dataType : "json",
		success : function (result){
			var str = '<select>';
			var objson = eval(result);
			for(var o in objson) {
				 str += '<option value="' + o + '">' + objson[o] + '</option>';
			}
			$("#City").empty().append($(">option", str + '</select>'));
			if(city !="0"){
				$("#City").val(city);
			}
			getDistrictList($("#Province").val()+$("#City").val(),district);
		},
		error : function(e) {
			alert(e);
		}
	});
}

function getDistrictList(id,district)
{
  $.ajax( {
		type : "GET",
		url : "http://data.weather.com.cn/city3jdata/station/"+ id +".html",
		cache : false,
		data : {},
		dataType : "json",
		success : function (result){
			var str = '<select>';
			var objson = eval(result);
			for(var o in objson) {
				 str += '<option value="' + o + '">' + objson[o] + '</option>';
			}
			$("#District").empty().append($(">option", str + '</select>'));
			if(district != "0"){
				$("#District").val(district);
			}
			locationChanged();
		},
		error : function(e) {
			alert(e);
		}
	});
}

// 初始化配置界面
//
function initSettingPanel() {
	loadSettings();
    var province = gDefaults.province;
    var city = gDefaults.city;
    var district = gDefaults.district;
    if (province == "99") {
        city = "0";
        district = "0";
    }
	getProvinceList(province,city,district);
    // 省份选择
	$("#Province").change(function() {
		getCityList($("#Province").val(),0,0);
    });
    // 城市选择
    $("#City").change(function() {
		getDistrictList($("#Province").val()+$("#City").val(),0);
    });
    // 区县选择
    $("#District").change(function() {
		locationChanged();
    });
}
// 位置被改变时
//
function locationChanged() {
    updateSettings();
}
//
// 更新配置信息
//
function updateSettings() {
    gDefaults.province = $("#Province").val();
    if (gDefaults.province != "99") {
        gDefaults.city = $("#City").val();
        gDefaults.district = $("#District").val();
    }
	else
	{
		gDefaults.city = '';
        gDefaults.district = '';	
	}
	if($("#Province").val() =='10131')
	{
		$("#yourcity").text($("#District").val());
		$("#cityname").text($("#District option:selected").text());
	}
	else
	{
		$("#yourcity").text($("#Province").val()+$("#City").val()+$("#District").val());
		$("#cityname").text($("#District option:selected").text());
	}
	
	
	//System.Gadget.Settings.writeString("district",$("#yourcity").text()); 
}